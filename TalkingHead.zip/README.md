# TalkingHeadAddOn
TO abe able to run the code in a browser, these are the steps to be followed.
Clone or download the code from the repository into a local machine in a folder.
Go to chrome://extensions/ and check the box for Developer mode in the top right.
Click the Load unpacked extension button and select the unzipped folder for your extension to install it.
Your extensions are visible as icon to the right of your address bar after installation.
Click on the icon to test the plugin.
